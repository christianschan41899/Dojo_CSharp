﻿using System;
using System.Collections.Generic;

namespace Hungry_Ninja
{
    class Food
    {
        public string Name;
        public int Calories;
        // Foods can be Spicy and/or Sweet
        public bool IsSpicy; 
        public bool IsSweet; 
        // add a constructor that takes in all four parameters: Name, Calories, IsSpicy, IsSweet
        public Food(string name, int cal, bool spicy, bool sweet)
        {
            this.Name = name;
            this.Calories = cal;
            this.IsSpicy = spicy;
            this.IsSweet = sweet;
        }
    }

    class Buffet
    {
        public List<Food> Menu;
         
        //constructor
        public Buffet()
        {
            Menu = new List<Food>()
            {
                new Food("Peanuts", 828, false, false),
                new Food("Mango", 201, false, true),
                new Food("Shrimp", 100, false, false),
                new Food("Steak", 679, false, false),
                new Food("Bell Pepper", 30, true, false),
                new Food("Orange Chicken", 490, true, true),
                new Food("Steak", 679, false, false)
            };
        }

        public Food Serve()
        {
            Random food = new Random();
            int foodIndex = food.Next(7);
            return (Menu[foodIndex]);
        }
    }

    class Ninja
    {
        private int calorieIntake;
        public List<Food> FoodHistory;
        
        // add a constructor

        public Ninja()
        {
            this.calorieIntake = 0;
            this.FoodHistory = new List<Food>();
        }
        
        // add a public "getter" property called "IsFull"
        public bool IsFull
        {
            get {return (this.calorieIntake >= 1200); }
        }
        // build out the Eat method
        public void Eat(Food item)
        {
            if(IsFull)
            {
                Console.WriteLine("This Ninja is full!");
            }
            else
            {
                calorieIntake += item.Calories;
                FoodHistory.Add(item);
                //For testing purposes
                //Console.WriteLine(item.Name);
            }
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Ninja ninja1 = new Ninja();
            Buffet buffet1 = new Buffet();
            Food eating;
            for(int i = 0; i < 7; i++)
            {
                eating = buffet1.Serve();
                ninja1.Eat(eating);
            }
        }
    }
}
