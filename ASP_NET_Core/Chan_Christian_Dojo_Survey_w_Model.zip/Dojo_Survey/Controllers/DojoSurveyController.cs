using Microsoft.AspNetCore.Mvc;
using UserModel.Models;

namespace DojoSurvey.Controllers
{
    public class DojoSurvey : Controller
    {
        [HttpGet("")]

        public ViewResult FormPage()
        {
            return View("FormPage");
        }

        [HttpPost("display")]

        public ViewResult FormDisplay(User formUser)
        {
            return View("FormDisplay", formUser);
        }
    }
}