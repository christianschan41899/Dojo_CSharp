using Microsoft.AspNetCore.Mvc;

namespace DojoSurvey.Controllers
{
    public class DojoSurvey : Controller
    {
        [HttpGet("")]

        public ViewResult FormPage()
        {
            return View("FormPage");
        }

        [HttpPost("display")]

        public ViewResult FormDisplay(string StringName, string StringLocation, string StringFavLang, string StringComment)
        {
            ViewBag.Name = StringName;
            ViewBag.Location = StringLocation;
            ViewBag.FavLang = StringFavLang;
            ViewBag.Comment = StringComment;
            return View("FormDisplay");
        }
    }
}